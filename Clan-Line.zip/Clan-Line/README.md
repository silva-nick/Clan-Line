# Clan-Line
This is an app created for the ISE 2018 Android app challenge.
Our app is a multiplayer Bluetooth game that involves tower pushing across two devices. 
